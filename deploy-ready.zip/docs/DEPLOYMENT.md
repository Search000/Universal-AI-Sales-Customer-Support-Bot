# Deploy (Render — free tier)

Makes the bot run 24/7 on the internet, so your PC doesn't need to stay on.
Render's free web service tier costs nothing; it can go to sleep after
15 minutes of no traffic and take ~30s to wake on the next request — fine
for a bot getting occasional messages, upgrade later only if that delay
becomes a problem.

## 1. Sign up
Go to https://render.com → sign up with your GitHub account (same one
that owns `Universal-AI-Sales-Customer-Support-Bot`).

## 2. Create the web service
1. Dashboard → "New +" → "Web Service".
2. Connect the `Universal-AI-Sales-Customer-Support-Bot` repo.
3. Fill in:
   - **Root Directory**: `backend`
   - **Runtime**: Python 3
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn -w 2 -b 0.0.0.0:$PORT main:app`
   - **Instance Type**: Free

## 3. Environment variables
In the same setup screen (or later under "Environment"), add these — same
values as your local `backend/.env`, with one change:

- `APP_ENV` = `production`
- `GOOGLE_SPREADSHEET_ID` = (your spreadsheet ID)
- `GOOGLE_SERVICE_ACCOUNT_JSON` = paste the **entire contents** of your
  `service-account.json` file as one value (Render has no file upload for
  this — that's why the app supports this env-var form; see
  `app/integrations/sheets/client.py`). Do NOT also set
  `GOOGLE_SERVICE_ACCOUNT_FILE`.
- `GEMINI_API_KEY`, `GEMINI_MODEL`
- `OWNER_API_KEY`
- `RATE_LIMIT_PER_MINUTE`
- `META_APP_SECRET`, `META_PAGE_ACCESS_TOKEN`, `META_VERIFY_TOKEN` (once you have them — Phase 10 setup)
- `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID` (once you have them — Phase 11 setup)

## 4. Deploy
Click "Create Web Service". Render builds and deploys automatically. When
done, you get a public URL like:

```
https://your-app-name.onrender.com
```

## 5. Verify
- Open `https://your-app-name.onrender.com/health` → should show `{"status": "ok"}`.
- Open `https://your-app-name.onrender.com/dashboard/onboard` → the onboarding form should load.

## 6. Auto-deploy on every push
Render redeploys automatically every time you `git push` to `main` — no
extra step needed for future phases.

## 7. Use this URL for Facebook/WhatsApp
Facebook and WhatsApp webhooks require a public HTTPS URL — this Render
URL is what you'll paste into the Meta Developer dashboard:
- Facebook webhook URL: `https://your-app-name.onrender.com/webhooks/facebook`
- WhatsApp webhook URL: `https://your-app-name.onrender.com/webhooks/whatsapp`
