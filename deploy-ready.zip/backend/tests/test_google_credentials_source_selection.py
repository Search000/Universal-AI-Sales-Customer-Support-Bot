from app.config import config
from app.services import engine_factory


def test_json_credentials_alone_selected_as_real_sheets_source(monkeypatch):
    """Cloud hosts set GOOGLE_SERVICE_ACCOUNT_JSON instead of a file path —
    engine_factory must treat that as 'real Sheets configured' too."""
    monkeypatch.setattr(config, "GOOGLE_SERVICE_ACCOUNT_FILE", "")
    monkeypatch.setattr(config, "GOOGLE_SERVICE_ACCOUNT_JSON", '{"type": "service_account"}')
    monkeypatch.setattr(config, "GOOGLE_SPREADSHEET_ID", "fake-sheet-id")

    engine_factory.reset_for_tests()
    pipeline = engine_factory.get_message_pipeline()
    repo = engine_factory.get_repository()

    # It picked the real client class (we don't actually connect — no
    # network call happens until a sheet read is attempted).
    from app.integrations.sheets.client import GoogleSheetsClient

    assert isinstance(repo._client, GoogleSheetsClient)
    engine_factory.reset_for_tests()


def test_missing_both_file_and_json_falls_back_to_sample_data(monkeypatch):
    monkeypatch.setattr(config, "GOOGLE_SERVICE_ACCOUNT_FILE", "")
    monkeypatch.setattr(config, "GOOGLE_SERVICE_ACCOUNT_JSON", "")
    monkeypatch.setattr(config, "GOOGLE_SPREADSHEET_ID", "")

    engine_factory.reset_for_tests()
    repo = engine_factory.get_repository()

    from app.integrations.sheets.fake_client import FakeSheetsClient

    assert isinstance(repo._client, FakeSheetsClient)
    engine_factory.reset_for_tests()
